package TestPages;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class ORTest {
	@Test
	public void TestConfig() throws Exception{
		//to access property file
		File src=new File("./Config/property.property");
		//
		FileInputStream fis=new FileInputStream(src);
		Properties pro=new Properties();
		pro.load(fis);
		WebDriver driver=new FirefoxDriver();
		String url=pro.getProperty("url");
		driver.get(url);
		driver.findElement(By.xpath(pro.getProperty("username"))).sendKeys(pro.getProperty("name"));
		driver.findElement(By.xpath(pro.getProperty("lastname"))).sendKeys("Shetty");
		Thread.sleep(2003);
		
		
	}
}
