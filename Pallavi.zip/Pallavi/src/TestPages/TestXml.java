package TestPages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class TestXml {
	@Test
	public void exam() throws FileNotFoundException, DocumentException{
	File src=new File("./Config/NewFile.xml");
	FileInputStream fis=new FileInputStream(src);
	SAXReader saxReader=new SAXReader();
	Document document=saxReader.read(fis);
	WebDriver driver=new FirefoxDriver();
	driver.get("file://localhost/D:/Users/ADM-IG-HWDLAB1B/Desktop/WorkingWithForms.html");
	driver.findElement(By.xpath(document.selectSingleNode("//WWW/username").getText())).sendKeys("Adesh");
	//driver.findElement(By.xpath(document.selectSingleNode("//WWW/firstname").getText())).sendKeys("Adesh");
	driver.findElement(By.xpath(document.selectSingleNode("//WWW/lastname").getText())).sendKeys("Shetty");
	try {
		Thread.sleep(2000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	//driver.findElement(By.name(document.selectSingleNode("//WWW/uname").getText())).sendKeys("");


}

}