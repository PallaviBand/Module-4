package TestPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import Ashu.Data;

public class NewTest {
	 @Test
	  public void verifylogin() {
		  WebDriver driver=new FirefoxDriver();
		  driver.get("file://localhost/D:/Users/ADM-IG-HWDLAB1B/Desktop/WorkingWithForms.html");
		  Data fnl=new Data(driver);
		  fnl.setUname(By.id("txtFirstName"));
		  fnl.setLn(By.id("txtLastName"));
		  fnl.typeuname("Adesh");
		  fnl.typeln("Shetty");
	  }
}
