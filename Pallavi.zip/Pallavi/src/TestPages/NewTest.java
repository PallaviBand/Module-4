package TestPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;


import Ashu.Data;

public class NewTest {
	 @Test
     public void verify(){
    	 WebDriver driver=new FirefoxDriver();
    	 driver.get("file://localhost/D:/Users/ADM-IG-HWDLAB1B/Desktop/WorkingWithForms.html");
    	 Data fl=PageFactory.initElements(driver,Data.class);
         fl.typetext("Adesh","Ghosh","12345","12345"); 
         }
}
