package Ashu;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Data {
	WebDriver driver;
	By uname;
	By ln;
	
	
	public Data(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	public WebDriver getDriver() {
		return driver;
	}
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	public By getUname() {
		return uname;
	}
	public void setUname(By uname) {
		this.uname = uname;
	}
	public By getLn() {
		return ln;
	}
	public void setLn(By ln) {
		this.ln = ln;
	}
	
	public void typeuname(String name){
		driver.findElement(uname).sendKeys(name);
	}
	public void typeln(String lname){
		driver.findElement(uname).clear();
		driver.findElement(ln).sendKeys(lname);
	}

}
