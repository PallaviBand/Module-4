package Ashu;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Data {
	WebDriver driver;
	//finding elements
	  @FindBy(id="txtUserName")
	  @CacheLookup
	  WebElement uname;
	  
	  //using how class
	  @FindBy(how=How.ID,using="txtLastName")
	  @CacheLookup
	  WebElement ln;
	  
	  
		  
		   //finding elements
		    @FindBy(name="txtFN")
		    @CacheLookup
		    WebElement fn;
		    
		    //using how class
		    @FindBy(how=How.ID,using="txtConfPassword")
		    @CacheLookup
		    WebElement Cpass;

	public Data(WebDriver driver) {
		this.driver = driver;
	}
	public void typetext(String suname,String sln,String ppass,String cpass){
		uname.sendKeys(suname);
		ln.sendKeys(sln);
		fn.sendKeys(ppass);
		Cpass.sendKeys(cpass);
	}
		
}
